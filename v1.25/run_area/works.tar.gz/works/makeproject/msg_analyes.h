//
//  msg_analyes.h
//  Texas_and_fuck
//
//  Created by mac on 5/28/15.
//  Copyright (c) 2015 mac. All rights reserved.
//

void msg_handle(char *str);
