//
//  anction.h
//  test12
//
//  Created by mac on 5/27/15.
//  Copyright (c) 2015 mac. All rights reserved.
//

#ifndef test12_action_h
#define test12_action_h 
void Action();

#endif
