//
//  winpro.h
//  Texas_and_fuck
//
//  Created by mac on 5/28/15.
//  Copyright (c) 2015 mac. All rights reserved.
//

#ifndef _WINPRO_H_
#define _WINPRO_H_


double winpro(int myhand[2], int poker[], int pokern, int playn);
#endif